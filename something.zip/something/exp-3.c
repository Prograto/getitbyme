#include<stdio.h>
#include<conio.h>
#include<string.h>

// Grammar productions (left-hand side)
char prol[7][10] = {"S", "A", "A", "B", "B", "C", "C"};
// Corresponding right-hand sides of productions
char pror[7][10] = {"Aa", "Bb", "Cd", "aB", "@", "Cc", "@"};
// Production rules in formatted form
char prod[7][10] = {"S-->A", "A-->Bb", "A-->Cd", "B-->aB", "B-->", "C-->Cc", "C-->"};
// First sets for each non-terminal
char first[7][10] = {"abcd", "ab", "cd", "a@", "@", "c@", "@"};
// Follow sets for each non-terminal
char follow[7][10] = {"$", "$", "$", "a$", "b$", "c$", "d$"};
// Parsing table
char table[5][6][10];

/* Function to get the index of a symbol */
int numr(char c) {
    switch (c) {
        case 'S': return 0;
        case 'A': return 1;
        case 'B': return 2;
        case 'C': return 3;
        case 'a': return 0;
        case 'b': return 1;
        case 'c': return 2;
        case 'd': return 3;
        case '$': return 4;
        default: return -1;
    }
}

void main() {
    int i, j, k;

    // Initialize parsing table with empty strings
    for (i = 0; i < 5; i++)
        for (j = 0; j < 6; j++)
            strcpy(table[i][j], " ");

    printf("\n The following is the predictive parsing table for the following grammar:\n");
    for (i = 0; i < 7; i++)
        printf("%s\n", prod[i]);

    printf("\n Predictive parsing table is:\n ");

    // Fill parsing table based on FIRST sets
    for (i = 0; i < 7; i++) {
        k = strlen(first[i]);
        for (j = 0; j < k; j++) {
            if (first[i][j] != '@') // Ignore epsilon transitions for now
                strcpy(table[numr(prol[i][0]) + 1][numr(first[i][j]) + 1], prod[i]);
        }
    }

    // Handle epsilon (`@`) productions using FOLLOW sets
    for (i = 0; i < 7; i++) {
        if (strlen(pror[i]) == 1 && pror[i][0] == '@') { // If production is epsilon
            k = strlen(follow[i]);
            for (j = 0; j < k; j++)
                strcpy(table[numr(prol[i][0]) + 1][numr(follow[i][j]) + 1], prod[i]);
        }
    }

    // Assign table headers (terminals and non-terminals)
    strcpy(table[0][0], " ");
    strcpy(table[0][1], "a");
    strcpy(table[0][2], "b");
    strcpy(table[0][3], "c");
    strcpy(table[0][4], "d");
    strcpy(table[0][5], "$");
    strcpy(table[1][0], "S");
    strcpy(table[2][0], "A");
    strcpy(table[3][0], "B");
    strcpy(table[4][0], "C");

    // Print the predictive parsing table
    printf("\n--------------------------------------------------\n");
    for (i = 0; i < 5; i++) {
        for (j = 0; j < 6; j++) {
            printf("%s\t", table[i][j]);
            if (j == 5)
                printf("\n--------------------------------------------\n");
        }
    }
    getch(); // Wait for user input before closing
}
